-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2021 at 04:19 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_email` varchar(50) NOT NULL,
  `admin_name` varchar(20) NOT NULL,
  `admin_dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mob` int(11) DEFAULT NULL,
  `img_loc` varchar(30) DEFAULT NULL,
  `blood_group` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_email`, `admin_name`, `admin_dob`, `gender`, `mob`, `img_loc`, `blood_group`) VALUES
('admin@gmail.com', 'admin', '0000-00-00', 'male', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_detail`
--

CREATE TABLE `appointment_detail` (
  `appointment_ID` int(11) NOT NULL,
  `specialization_ID` int(11) NOT NULL,
  `doctor_email` varchar(50) NOT NULL,
  `patient_email` varchar(50) NOT NULL,
  `patient_name` varchar(20) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` varchar(8) NOT NULL DEFAULT current_timestamp(),
  `appointment_status` varchar(20) NOT NULL,
  `paying_status` varchar(6) NOT NULL,
  `homecare_present` int(1) NOT NULL,
  `homecare_ID` int(11) NOT NULL,
  `address` int(250) DEFAULT NULL,
  `mode` varchar(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_detail`
--

INSERT INTO `appointment_detail` (`appointment_ID`, `specialization_ID`, `doctor_email`, `patient_email`, `patient_name`, `appointment_date`, `appointment_time`, `appointment_status`, `paying_status`, `homecare_present`, `homecare_ID`, `address`, `mode`) VALUES
(43, 15, 'brightland@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 0, 0, NULL, NULL),
(44, 0, 'kandwalji@gmail.com', 'alpha@gmail.com', 'homcare_ID', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 1, 17, 253, NULL),
(45, 15, 'naughty@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 0, 0, NULL, NULL),
(46, 15, 'brightland@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 0, 0, NULL, NULL),
(47, 15, 'naughty@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 0, 0, NULL, NULL),
(48, 15, 'brightland@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', 0, 0, NULL, NULL),
(49, 15, 'dpjoshi@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-30', '12:52 pm', 'rescheduled', 'unpaid', 0, 0, NULL, NULL),
(50, 0, 'kandwalji@gmail.com', 'alpha@gmail.com', 'homcare_ID', '2020-03-12', '12:30 pm', 'applied', 'unpaid', 1, 17, 253, NULL),
(51, 15, 'godslayer@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'completed', 'unpaid', 0, 0, NULL, NULL),
(52, 15, 'godslayer@gmail.com', 'alpha@gmail.com', 'specialization', '2001-03-25', '12:30 pm', 'completed', 'unpaid', 0, 0, NULL, NULL),
(53, 15, 'godslayer@gmail.com', 'alpha@gmail.com', 'homcare_ID', '2021-03-31', '12:30 pm', 'completed', 'unpaid', 0, 0, NULL, NULL),
(54, 0, 'kandwalji@gmail.com', 'alpha@gmail.com', 'homcare_ID', '2021-03-31', '12:30 pm', 'applied', 'unpaid', 1, 18, 253, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_ID` int(11) NOT NULL,
  `branch_name` varchar(30) NOT NULL,
  `branch_number` int(11) NOT NULL,
  `branch_address` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_ID`, `branch_name`, `branch_number`, `branch_address`) VALUES
(1, 'dehradun', 2147483647, 'alpha d col </br> dded c,dkked'),
(2, 'rurki', 2147483647, 'alpha d col </br> dded c,dkked'),
(3, 'abc', 2147483647, 'alpha d col </br> dded c,dkked'),
(4, 'def', 2147483647, 'alpha d col </br> dded c,dkked'),
(5, 'ghi', 2147483647, 'alpha d col </br> dded c,dkked'),
(14, 'Rora Branch', 108100, 'Fakeer gali, kabadi bajaar, thakeeli builing ke aage wali mat wala bhi');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doctor_email` varchar(50) NOT NULL,
  `doctor_name` varchar(20) NOT NULL,
  `doctor_dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mob` int(11) NOT NULL,
  `img_loc` varchar(30) NOT NULL,
  `visit_hour_start` varchar(8) NOT NULL,
  `visit_hour_end` varchar(8) NOT NULL,
  `specialization_ID` int(11) NOT NULL,
  `branch` varchar(30) DEFAULT NULL,
  `homecare_id` int(11) DEFAULT NULL,
  `homecare_present` tinyint(4) NOT NULL,
  `appointment_fee` int(11) NOT NULL,
  `blood_group` varchar(3) DEFAULT NULL,
  `specialization` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_email`, `doctor_name`, `doctor_dob`, `gender`, `mob`, `img_loc`, `visit_hour_start`, `visit_hour_end`, `specialization_ID`, `branch`, `homecare_id`, `homecare_present`, `appointment_fee`, `blood_group`, `specialization`) VALUES
('brightland@gmail.com', 'Harshu Singh', '0000-00-00', 'female', 2147483647, '', '8:00 AM', '4:00 PM', 1, '1', NULL, 1, 300, NULL, 'Anaesthesiologists'),
('dpjoshi@gmail.com', 'D.P Joshi', '0000-00-00', 'male', 2147483647, '', '8:00 AM', '4:00 PM', 1, '1', NULL, 0, 500, NULL, 'Anaesthesiologists'),
('godslayer@gmail.com', 'God Slayer', '5200-02-12', 'female', 2147483647, '6001cee560f061.41873813.jpeg', '8:00 AM', '4:00 PM', 1, '2', NULL, 1, 100, 'A+', 'Anaesthesiologists'),
('kandwalji@gmail.com', 'Vijay Kandwal', '2021-03-12', 'male', 2147483647, '6001cee560f061.41873813.jpeg', '8:00 AM', '4:00 PM', 1, '2', NULL, 1, 300, 'A+', 'Physiotherapy'),
('mono@gmail.com', 'mono thakur', '0000-00-00', 'female', 2147483647, '', '8:00 AM', '4:00 PM', 8, '2', NULL, 0, 200, NULL, 'Anaesthesiologists'),
('moti@gmail.com', 'Shikha Bhatt', '0000-00-00', 'female', 2147483647, '', '8:00 AM', '4:00 PM', 8, '1', NULL, 1, 200, NULL, 'Anaesthesiologists'),
('naughty@gmail.com', 'Gangeshwar Nautiyal', '0000-00-00', 'male', 2147483647, '', '8:00 AM', '4:00 PM', 8, '1', NULL, 0, 4999, NULL, 'Anaesthesiologists');

-- --------------------------------------------------------

--
-- Table structure for table `homecare_detail`
--

CREATE TABLE `homecare_detail` (
  `appointment_id` int(11) NOT NULL,
  `homecare_ID` int(11) NOT NULL,
  `doctor_email` varchar(50) NOT NULL,
  `patient_email` varchar(50) NOT NULL,
  `patient_name` varchar(20) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` varchar(8) NOT NULL,
  `appointment_status` varchar(20) NOT NULL,
  `paying_status` varchar(6) NOT NULL,
  `address` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `homecare_detail`
--

INSERT INTO `homecare_detail` (`appointment_id`, `homecare_ID`, `doctor_email`, `patient_email`, `patient_name`, `appointment_date`, `appointment_time`, `appointment_status`, `paying_status`, `address`) VALUES
(1, 57, 'moti@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', '253'),
(2, 17, 'brightland@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', '253'),
(3, 18, 'godslayer@gmail.com', 'alpha@gmail.com', 'specialization', '2001-02-23', '12:30 pm', 'applied', 'unpaid', '253'),
(4, 18, 'brightland@gmail.com', 'alpha@gmail.com', 'specialization', '2021-03-12', '12:30 pm', 'applied', 'unpaid', '253'),
(5, 17, 'godslayer@gmail.com', 'alpha@gmail.com', 'specialization', '2002-03-12', '12:30 pm', 'applied', 'unpaid', '253');

-- --------------------------------------------------------

--
-- Table structure for table `home_care`
--

CREATE TABLE `home_care` (
  `homecare_ID` int(11) NOT NULL,
  `homecare_category` varchar(50) NOT NULL,
  `homecare_subcategory` varchar(50) NOT NULL,
  `homecare_responsible` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `home_care`
--

INSERT INTO `home_care` (`homecare_ID`, `homecare_category`, `homecare_subcategory`, `homecare_responsible`) VALUES
(17, 'Physiotherapy', 'Post Neuro Injury', 'doctor'),
(18, 'Physiotherapy', 'Post Spinal Injury\r\n', 'doctor'),
(19, 'Physiotherapy', ' Orthopaedic Injury\r\n', 'doctor'),
(20, 'Physiotherapy', 'Paediatric Injury', 'doctor'),
(21, 'Physiotherapy', 'Cardio Vascular Pulmonary', 'doctor'),
(22, 'Physiotherapy', 'Post Operative Rehab', 'doctor'),
(23, 'Physiotherapy', 'Accidental bone or muscle injury', 'doctor'),
(24, 'Physiotherapy', 'Community Physiotherapy', 'doctor'),
(25, 'VACCINATION', 'polio', 'doctor,nurse'),
(26, 'VACCINATION', 'corona', 'doctor,nurse'),
(27, 'VACCINATION', 'vaci1', 'doctor,nurse'),
(28, 'VACCINATION', 'vaci2', 'doctor,nurse'),
(29, 'VACCINATION', 'vaci3', 'doctor,nurse'),
(30, 'VACCINATION', 'vaci4', 'doctor,nurse'),
(31, 'VACCINATION', 'vaci5', 'doctor,nurse'),
(32, 'VACCINATION', 'vaci6', 'doctor,nurse'),
(33, 'VACCINATION', 'vaci8', 'doctor,nurse'),
(34, 'VACCINATION', 'vaci9', 'doctor,nurse'),
(35, 'VACCINATION', 'vaci10', 'doctor,nurse'),
(36, 'VACCINATION', 'vaci11', 'doctor,nurse'),
(37, 'LAB TEST', 'Urine Test', 'lab_assistant'),
(38, 'LAB TEST', 'Blood Test', 'lab_assistant'),
(39, 'LAB TEST', 'Blood Preasure Test', 'lab_assistant'),
(40, 'LAB TEST', 'Sugar Test', 'lab_assistant'),
(41, 'LAB TEST', 'Meningitis Test', 'lab_assistant'),
(42, 'LAB TEST', 'Testicular checks', 'lab_assistant'),
(43, 'LAB TEST', 'Be breast aware', 'lab_assistant'),
(44, 'LAB TEST', 'Checking your heart rate', 'lab_assistant'),
(45, 'LAB TEST', 'Skin check', 'lab_assistant'),
(46, 'LAB TEST', 'Test 10', 'lab_assistant'),
(47, 'NURSING ATTENDANTS', '3 Hrs', 'nurse'),
(48, 'NURSING ATTENDANTS', '8 Hrs', 'nurse'),
(49, 'NURSING ATTENDANTS', '12 Hrs', 'nurse'),
(50, 'NURSING ATTENDANTS', '24 Hrs', 'nurse'),
(51, 'CARE FOR PREGNANT MOTHERS AND BABIES', '3 Hrs', 'nurse'),
(52, 'CARE FOR PREGNANT MOTHERS AND BABIES', '8 Hrs', 'nurse'),
(53, 'CARE FOR PREGNANT MOTHERS AND BABIES', '12 Hrs', 'nurse'),
(54, 'CARE FOR PREGNANT MOTHERS AND BABIES', '24 Hrs', 'nurse'),
(55, 'HOME CLEANLINESS ASSISTANCE', 'None', 'sweeper'),
(56, 'SPECIALLY ABLED CHILD MANAGEMENT', 'None', 'nurse'),
(57, 'NUTRITION SERVICES', 'None', 'doctor');

-- --------------------------------------------------------

--
-- Table structure for table `lab_assistants`
--

CREATE TABLE `lab_assistants` (
  `la_email` varchar(50) NOT NULL,
  `la_name` varchar(20) NOT NULL,
  `la_dob` date NOT NULL,
  `la_gender` varchar(6) NOT NULL,
  `mob` int(11) NOT NULL,
  `img_loc` varchar(30) DEFAULT NULL,
  `visit_hour_start` varchar(8) DEFAULT NULL,
  `visit_hour_end` varchar(8) DEFAULT NULL,
  `charges` int(11) NOT NULL,
  `branches` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nurses`
--

CREATE TABLE `nurses` (
  `nurse_email` varchar(50) NOT NULL,
  `nurse_name` varchar(20) NOT NULL,
  `nurse_dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mob` int(11) NOT NULL,
  `img_loc` varchar(30) DEFAULT NULL,
  `branch` varchar(30) NOT NULL,
  `blood_group` varchar(3) DEFAULT NULL,
  `homecare_id` int(11) NOT NULL,
  `homecare_present` int(1) NOT NULL,
  `homecare_available` int(1) NOT NULL,
  `homecare_fee` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `user_email` varchar(50) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mob` int(11) NOT NULL,
  `img_loc` varchar(30) DEFAULT NULL,
  `blood_group` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`user_email`, `user_name`, `user_dob`, `gender`, `mob`, `img_loc`, `blood_group`) VALUES
('alpha@gmail.com', 'Gaurav Arora', '2000-08-15', 'female', 2147483647, '6001cee560f061.41873813.jpeg', 'O-'),
('alpha@gmail.come', 'abc', '5120-02-14', 'male', 125326, NULL, ''),
('alpha@gmail.comr', 'abc', '5200-02-12', 'male', 253265, NULL, ''),
('alpha@gmail.comt', 'abc', '5212-12-25', 'male', 12532522, NULL, 'A+'),
('alpha@gmail.comx', 'alphabeta', '0200-05-12', 'male', 25362568, NULL, ''),
('gauravarora1@gmail.com', 'Brightlands', '2000-11-29', 'other', 902795112, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prescribed_medicine`
--

CREATE TABLE `prescribed_medicine` (
  `prescibe_ID` int(11) NOT NULL,
  `medicine` varchar(50) NOT NULL,
  `appointment_ID` int(11) NOT NULL,
  `morning` varchar(3) NOT NULL,
  `afternoon` varchar(3) NOT NULL,
  `evening` varchar(3) NOT NULL,
  `take_medicine` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `prescribed_medicine`
--

INSERT INTO `prescribed_medicine` (`prescibe_ID`, `medicine`, `appointment_ID`, `morning`, `afternoon`, `evening`, `take_medicine`) VALUES
(1, '34', 31, 'NO', 'YES', 'NO', 'after'),
(2, '35', 31, 'NO', 'YES', 'NO', 'after'),
(3, '37', 30, 'YES', 'NO', 'NO', 'before'),
(4, '35', 30, 'YES', 'NO', 'NO', 'before'),
(5, '34', 30, 'YES', 'NO', 'NO', 'before'),
(6, '37', 29, 'YES', 'NO', 'NO', 'before'),
(7, '34', 29, 'YES', 'NO', 'NO', 'before'),
(8, '37', 29, 'YES', 'NO', 'NO', 'before'),
(9, '35', 32, 'YES', 'NO', 'NO', 'after'),
(10, '34', 32, 'YES', 'NO', 'NO', 'before'),
(11, '34', 33, 'YES', 'NO', 'NO', 'before'),
(12, '37', 33, 'YES', 'NO', 'NO', 'before'),
(13, '35', 32, 'YES', 'YES', 'NO', 'after'),
(14, '37', 32, 'YES', 'YES', 'NO', 'after'),
(15, '34', 32, 'YES', 'YES', 'NO', 'after'),
(16, '35', 32, 'YES', 'YES', 'NO', 'after'),
(17, '37', 32, 'YES', 'YES', 'NO', 'before'),
(18, '34', 32, 'YES', 'YES', 'NO', 'before'),
(19, '35', 32, 'YES', 'YES', 'NO', 'before'),
(20, '37', 33, 'YES', 'NO', 'NO', 'after'),
(21, '34', 33, 'YES', 'NO', 'NO', 'after'),
(22, '35', 33, 'YES', 'NO', 'NO', 'after'),
(23, '37', 33, 'YES', 'NO', 'NO', 'after'),
(24, '34', 34, 'YES', 'YES', 'YES', 'before'),
(25, '35', 34, 'NO', 'YES', 'NO', 'before'),
(26, '37', 34, 'NO', 'YES', 'YES', 'before'),
(27, '34', 51, 'YES', 'NO', 'NO', 'before'),
(28, '35', 51, 'YES', 'NO', 'NO', 'before'),
(29, '35', 52, 'NO', 'YES', 'NO', 'after'),
(30, '34', 52, 'NO', 'YES', 'NO', 'after'),
(31, '37', 52, 'NO', 'YES', 'NO', 'after'),
(32, '37', 53, 'YES', 'YES', 'NO', 'before'),
(33, '34', 53, 'YES', 'YES', 'YES', 'after');

-- --------------------------------------------------------

--
-- Table structure for table `specialization`
--

CREATE TABLE `specialization` (
  `spe_ID` int(11) NOT NULL,
  `spe_name` varchar(30) NOT NULL,
  `spe_mode` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specialization`
--

INSERT INTO `specialization` (`spe_ID`, `spe_name`, `spe_mode`) VALUES
(14, 'Allergists/Immunologists', 'None'),
(15, 'Anaesthesiologists', 'None'),
(16, 'Cardiologists', 'None'),
(17, 'Colon and Rectal Surgeons', 'None'),
(18, 'Critical Care Medicine Special', 'None'),
(19, 'Dermatologists', 'None'),
(20, 'Endocrinologists', 'None'),
(21, 'Emergency Medicine Specialists', 'None'),
(22, 'Family Physicians', 'None'),
(23, 'Gastroenterologists', 'None'),
(24, 'Geriatric Medicine Specialists', 'None'),
(33, 'Haematologist', 'None'),
(34, 'Hospice and Palliative Medicin', 'None'),
(35, 'Infectious Disease Specialists', 'None'),
(36, 'Internists', 'None'),
(37, 'Medical Geneticists', 'None'),
(38, 'Nephrologists', 'None'),
(39, 'Neurologists', 'None'),
(40, 'Obstetricians and Gynecologist', 'None'),
(41, 'Oncologists', 'None'),
(42, 'Ophthalmologists', 'None'),
(43, 'Osteopaths', 'None'),
(44, 'Otolaryngologists', 'None'),
(45, 'Pathologists', 'None'),
(46, 'Paediatricians', 'None'),
(47, 'Physiatrists', 'None'),
(48, 'Plastic Surgeons ', 'None'),
(49, 'Podiatrists', 'None'),
(50, 'Preventive Medicine Specialist', 'None'),
(51, 'Psychiatrists', 'None'),
(52, 'Pulmonologists', 'None'),
(53, 'Radiologists', 'None'),
(54, 'Rheumatologists', 'None'),
(55, 'Sleep Medicine Specialists', 'None'),
(56, 'Sports Medicine Specialists ', 'None'),
(57, 'General Surgeons', 'None'),
(58, 'Urologists', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `sweepers`
--

CREATE TABLE `sweepers` (
  `sw_email` varchar(50) NOT NULL,
  `sw_name` varchar(20) NOT NULL,
  `sw_dob` date NOT NULL,
  `mob` int(11) NOT NULL,
  `img_loc` varchar(30) NOT NULL,
  `visit_hour_start` varchar(8) NOT NULL,
  `visit_hour_end` varchar(8) NOT NULL,
  `branch` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userEmail` varchar(50) NOT NULL,
  `userPassword` varchar(50) NOT NULL,
  `userPriv` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userEmail`, `userPassword`, `userPriv`) VALUES
('admin@gmail.com', 'admin', 'admin'),
('alpha@gmail.com', 'alphabeta', 'patient'),
('alpha@gmail.come', 'alphabeta', 'patient'),
('alpha@gmail.comr', 'alphabeta', 'patient'),
('alpha@gmail.comt', 'alphabeta', 'patient'),
('alpha@gmail.comx', 'alphabeta', 'patient'),
('bps@gmail.com', 'Nautiyal', 'doctor'),
('brightland@gmail.com', '12345678', 'doctor'),
('dpjoshi@gmail.com', '78945612', 'doctor'),
('gauravarora1@gmail.com', 'rorafrombirhgtlands', 'patient'),
('godslayer@gmail.com', 'godslayer', 'doctor'),
('kandwalji@gmail.com', '78945612', 'doctor'),
('mono@gmail.com', 'mononotsocool', 'doctor'),
('moti@gmail.com', 'Shikha Bhatt', 'doctor');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_email`);

--
-- Indexes for table `appointment_detail`
--
ALTER TABLE `appointment_detail`
  ADD PRIMARY KEY (`appointment_ID`);

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_ID`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doctor_email`);

--
-- Indexes for table `homecare_detail`
--
ALTER TABLE `homecare_detail`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `home_care`
--
ALTER TABLE `home_care`
  ADD PRIMARY KEY (`homecare_ID`);

--
-- Indexes for table `lab_assistants`
--
ALTER TABLE `lab_assistants`
  ADD PRIMARY KEY (`la_email`);

--
-- Indexes for table `nurses`
--
ALTER TABLE `nurses`
  ADD PRIMARY KEY (`nurse_email`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`user_email`);

--
-- Indexes for table `prescribed_medicine`
--
ALTER TABLE `prescribed_medicine`
  ADD PRIMARY KEY (`prescibe_ID`);

--
-- Indexes for table `specialization`
--
ALTER TABLE `specialization`
  ADD PRIMARY KEY (`spe_ID`);

--
-- Indexes for table `sweepers`
--
ALTER TABLE `sweepers`
  ADD PRIMARY KEY (`sw_email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userEmail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_detail`
--
ALTER TABLE `appointment_detail`
  MODIFY `appointment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `homecare_detail`
--
ALTER TABLE `homecare_detail`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `home_care`
--
ALTER TABLE `home_care`
  MODIFY `homecare_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `prescribed_medicine`
--
ALTER TABLE `prescribed_medicine`
  MODIFY `prescibe_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `specialization`
--
ALTER TABLE `specialization`
  MODIFY `spe_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
