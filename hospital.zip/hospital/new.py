"""
def add(*value): 
	addition = 0;
	for i in value : 
		addition = addition + i
	return addition

print(str(add(1,2,3))*4)

"""

var = "hello";
print(var)