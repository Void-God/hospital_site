<?php
  $conn = mysqli_connect("localhost","root","","capricor_pharmacy") or die ("Unable to connect");
?>