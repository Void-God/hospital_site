<?php
  $con = mysqli_connect("localhost","root","","hospital") or die ("Unable to connect");
?>